﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SibekoPresentation.Forms
{
    public partial class Dashboard_form : Form
    {

        int panelWidth;
        Boolean isCollasped;
        public Dashboard_form()
        {
            InitializeComponent();
            timerTime.Start();
            panelWidth = PanelLeft.Width;
            isCollasped = false;

            UserControls.UC_Home uhc = new UserControls.UC_Home();
            AddControlsToPanel(uhc);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isCollasped)
            {
                PanelLeft.Width = PanelLeft.Width + 10;
                 if (PanelLeft.Width >= panelWidth)
                {
                    timer1.Stop();
                    isCollasped = false;
                    this.Refresh();
                }
                 else
                {
                    PanelLeft.Width = PanelLeft.Width - 10;
                    if (PanelLeft.Width <= 60)
                    {
                        timer1.Stop();
                        isCollasped = true;
                        this.Refresh();
                    }
                }
            }
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timerTime_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            TimeLabel.Text = dateTime.ToString("HH:MM");

        }
        public void AddControlsToPanel(Control c)
        {
            c.Dock = DockStyle.Fill;
            panelControls.Controls.Clear();
            panelControls.Controls.Add(c);
        }
        private void btnHome_Click(object sender, EventArgs e)
        {
            UserControls.UC_Home uhc = new UserControls.UC_Home();
            AddControlsToPanel(uhc);
        }

        private void btnPos_Click(object sender, EventArgs e)
        {
            UserControls.UC_sales uc_sales = new UserControls.UC_sales();
            AddControlsToPanel(uc_sales);
        }

        private void btnStock_Click(object sender, EventArgs e)
        {
            UserControls.UC_StockPurchased uc_StockPurchased = new UserControls.UC_StockPurchased();
            AddControlsToPanel(uc_StockPurchased);
        }
    }
}

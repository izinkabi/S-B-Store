﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SibekoPresentation.Forms
{
    public partial class AddNewItem_Form : Form
    {
        public AddNewItem_Form()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Forms.AddCategory_Form addCategory_Form = new AddCategory_Form();
            addCategory_Form.ShowDialog();
        }

        private void btnAddBrand_Click(object sender, EventArgs e)
        {
            Forms.AddNewBrand_Form addNewBrand_Form = new AddNewBrand_Form();
        }
    }
}

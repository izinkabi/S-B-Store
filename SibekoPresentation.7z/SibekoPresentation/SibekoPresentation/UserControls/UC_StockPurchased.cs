﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SibekoPresentation.UserControls
{
    public partial class UC_StockPurchased : UserControl
    {
        public UC_StockPurchased()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Forms.AddNewItem_Form addNewItem_Form = new Forms.AddNewItem_Form();
            addNewItem_Form.ShowDialog();
        }
    }
}

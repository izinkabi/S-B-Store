﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SibekoPresentation.UserControls
{
    public partial class UC_sales : UserControl
    {
        public UC_sales()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Forms.CheckOut_Form checkOut_Form = new Forms.CheckOut_Form();
            checkOut_Form.ShowDialog();
        }
    }
}
